<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Selecionar Produto</title>
  <link rel="stylesheet" href="styleselecionarpedido.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>

<body>
  <header class="header">
    <div class="btns">
      <a href="login.html" class="button1" style="color: #000;">Login</a>
      <button id="cart-button">
        <i class="fas fa-shopping-cart"></i> Sacola
        <span id="cart-count">0</span>
      </button>
    </div>

    <h1 class="petfood">Pet Food</h1>
    <img class="imagem-logo" src="imagens/imagem.jpg" alt="">

    <div class="search">
      <form>
        <input type="text" class="search__input" id="busca" placeholder="Buscar...">
        <button class="button" type="submit">Buscar</button>
      </form>
    </div>
    <nav class="nav">
      <ul>
        <li><a href="#secao-de-destino">Sobre</a></li>
        <li><a href="#secao-de-destino1">Animais vivos</a></li>
        <li><a href="#secao-de-destino2">Animais congelados</a></li>
        <li><a href="#secao-de-destino3">Outros alimentos</a></li>
      </ul>
    </nav>
  </header>

  <img class="produto" src="imagens/grilo.webp" alt="">

  <div class="produtoselecionado">
    <h1 class="selec-prod">Selecionar Produto</h1>
    <div class="form">
    <br>

    <label for="produto">Produto Selecionado:</label>
    <select id="produto" name="produto">
      <option value="produto1">Grilo preto pacote com 10uni.</option>
    </select>
    <br><br>
    <label for="quantidade">Quantidade:</label>
    <input type="number" id="quantidade" value="0" oninput="calcularTotal()">
    <br><br>
    <label for="precoPorItem">Preço por Item (R$):</label>
    <input type="number" step="0.01" id="precoPorItem" value="25.00" oninput="calcularTotal()">
    <p id="total">Total: R$ 0.00</p>
    <button id="btn-sacola">Adicionar à Sacola</button>
  </div>

  <div class="avaliar-produto">
    <div>
      <p>Deixe sua avaliação:</p>
      <div class="rating" id="rating">
        <span data-rating="5">☆</span><span data-rating="4">☆</span><span data-rating="3">☆</span><span
          data-rating="2">☆</span><span data-rating="1">☆</span>
      </div>
    </div>

    <div>
      <p>Seu comentário:</p>
      <textarea id="comment" rows="4" cols="50"></textarea>
    </div>

    <button id="btn-avaliar">Enviar Avaliação</button>

    <p id="ratingText"></p>
    <p id="commentText"></p>

    <script src="stars.js"></script>
  </div>
  </div>
</body>

</html>