<?php


ob_start();
require('../sheep_core/config.php');
?>
<!DOCTYPE html>
<html lang="pt-br" >
<head >
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title>Admin</title>
        <link rel="stylesheet" href="desenvolvedor.css">
      
</head>
<body>

<header>
        <h1>Pet-Food</h1>
        <nav>
            <ul>
                <li><a href="#home">Home</a></li>
                <li><a href="#products">Admin Protutos</a></li>
               
            </ul>
        </nav>

        <style>
            /* Estilo para a lista de produtos */
            #lista-produtos {
              list-style-type: none;
              padding: 0;
            }
        
            /* Estilo para cada item da lista de produtos */
            #lista-produtos li {
              margin-bottom: 10px;
              padding: 10px;
              border: 1px solid #ddd;
            }
        
            /* Estilo para os botões de edição e exclusão */
            #lista-produtos button {
              margin-right: 5px;
              cursor: pointer;
            }
          </style>
        </head>
        <body>
        
        <ul id="lista-produtos"></ul>

    </header>

          <form action="filtros/criar.php" method="post" enctype="multipart/form-data">


          </script>
    </header>

    <section id="home"><br>
        <h2>Bem-vindo de volta ao nosso E-commerce desenvolvedor!</h2>
        <p>Adicione seu novo produto aqui!.</p>
    </section>
    <body>

    

        <div class="container">
            <h2>Adicionar Produto</h2>
            <form id="productForm">
                <label for="productImage">Imagem URL:</label>
                <input type="text" id="productImage" name="productImage" required>
        
                <label for="productName">Nome do Produto:</label>
                <input type="text" id="productName" name="productName" required>
        
                <label for="productPrice">Preço:</label>
                <input type="number" id="productPrice" name="productPrice" min="0" step="0.01" required>
        
                <label for="productQuantity">Quantidade:</label>
                <input type="number" id="productQuantity" name="productQuantity" min="1" required>
        
                <div class="col-md-12">
                        <button type="submit" class="btn btn-lg btn-primary"  style="width:100%;" name="criarProduto" >Salvar</button>
                    </div>

                  </div>
                  
                </div>
              </div>
            </div>
          </div>
        </div>
            </form>
      <!-- fim formulario  topo menu -->
      </section>
      </div>
        
       
    </div>

  <script src="assets/js/custom.js"></script>

 
  

</body>
</html>

<?php
ob_end_flush();
?>