<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Exemplo de Comunicação Frontend-Backend</title>
</head>
<body>

  <h1>Dados do Backend</h1>

  <script>
    // Insira aqui o código fetch
    fetch('http://localhost:3000/api/exemplo')
      .then(response => response.json())
      .then(data => console.log(data))
      .catch(error => console.error('Erro:', error));
  </script>

</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Comunicação Frontend-Backend</title>
</head>
<body>

  <h1>Dados do Backend</h1>

  <button onclick="fetchData()">Obter Dados</button>

  <script>
    async function fetchData() {
      try {
        const response = await fetch('http://localhost:3003/api/exemplo');
        if (!response.ok) {
          throw new Error(`Erro na solicitação: ${response.statusText}`);
        }

        const data = await response.json();
        console.log('Dados recebidos do backend:', data);
      } catch (error) {
        console.error('Erro:', error);
      }
    }
  </script>

</body>
</html>