<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finalização</title>
    <link rel="stylesheet" href="stylefinalizacao.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>

<body>
    <header class="header">
        <h1 class="petfood">Pet Food</h1>
        <img class="imagem-logo" src="imagens/imagem.jpg" alt="">
        <div class="search">
        </div>
    </header>

    <h1 class="title">Pedido Confirmado</h1>
    <main class="pedido realizado">
        <div class="texto1">
            <p>Seu pedido foi realizado com sucesso.</p>
            <p>Em breve você receberá um e-mail no endereço <a href="mailto:comprador@gmail.com">comprador@gmail.com</a> com todos os detalhes do pedido.</p>
            <button class="botão">Pagamento Concluído</button>
        </div>
    
        <div class="texto2">
            <p><strong>Informações do Pedido:</strong></p>
            <p>ID: 1515151515</p>
            <p>Total: R$ 64,00</p>
            <p>Forma de pagamento: Cartão de crédito</p>
            <p>Forma de envio: Correios PAC</p>
            <p>CEP de entrega: 13024 - 095</p>
            <p>* Os produtos serão enviados em até 10 dias após a aprovação do pagamento.</p>
        </div>
    </main>

</body>
</html>