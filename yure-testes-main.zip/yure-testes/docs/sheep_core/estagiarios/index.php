<?php

$w = 1;
$d = 1;
if($w == $d):
header('Location: https://webtecpr.com.br/');
endif;


