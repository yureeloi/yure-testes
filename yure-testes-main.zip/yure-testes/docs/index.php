<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" >
    <meta name="viewport" content="width=device-width, initial-scale=1.0" >
    <title>Home</title>
    <link rel="stylesheet" href="stylehome.css"> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>

<body>
    <header class="header">
        <div class="btns">
            <a href="login.html" class="button1" style="color: #000;">Login</a>
            <a href="usuario/desenvolvedor.php" class="button2" style="color: #000;">adm</a>
        </div>
        <h1 class="petfood">Pet Food</h1>
        <img class="imagem-logo" src="imagens/imagem.jpg" alt="">
        <div class="search">
            <form>
                <input type="text" class="search__input" id="busca" placeholder="Buscar...">
                <button class="button" type="submit">Buscar</button>
            </form>
        </div>
        <nav class="nav">
            <ul>
                <li><a href="#secao-de-destino">Sobre</a></li>
                <li><a href="#secao-de-destino1">Animais vivos</a></li>
                <li><a href="#secao-de-destino2">Animais congelados</a></li>
                <li><a href="#secao-de-destino3">Outros alimentos</a></li>
            </ul>
        </nav>
    </header>

    <!--texto sobre nos-->
    <div id="secao-de-destino" class="temas" >
        <p><strong>Sobre</strong></p>
    </div>
    <main>
        <div class="texto"> Bem-vindo à Pet Food, onde atendemos às necessidades alimentares de animais exóticos com
            paixão. Reconhecemos a importância de cuidados especiais e dietas específicas para essas criaturas
            únicas. Nossa seleção abrange uma variedade de espécies exóticas, de répteis a mamíferos, promovendo
            saúde e bem-estar. Além de produtos de alta qualidade.
            Junte-se a nós nessa jornada de cuidado, descoberta e conexão com o reino animal extraordinário. Venha
            para a Pet Food, unindo paixão e bem-estar animal!
        </div>
    </main>
    <!--texto sobre nos-->


    <div id="secao-de-destino1" method="POST" class="temas">
        <p><strong>Animais vivos</strong></p>
    </div>
    <p class="corpo-texto">
    <div class="card">
        <img src="imagens/grilo.webp" alt="#">
        <div>
            <h1>Grilo Preto</h1>
            <h2>Pacote com 10uni</h2>
            <span>R$ 25.00</span>
            <button>Comprar</button>
        </div>
    </div>
    <div class="card">
        <img src="imagens/bicho-da-seda-portal-agropecuario.jpg" alt="#">

        <div>
            <h1>Bicho da Seda</h1>
            <h2>Pacote com 40uni</h2>
            <span>R$ 40.00</span>
            <button>Comprar</button>
        </div>
    </div>
    <div class="card">
        <img src="imagens/gafanhoto.jpg" alt="#">

        <div>
            <h1>Gafanhoto Verde</h1>
            <h2>Pacote com 10uni</h2>
            <span>R$ 30.00</span>
            <button>Comprar</button>
        </div>
    </div>

    <div id="secao-de-destino2" class="temas">
        <p><strong>Animais congelados</strong></p>
    </div>
    <p class="corpo-texto">
    <div class="card">
        <img src="imagens/camundongo.jpg" alt="#">

        <div>
            <h1>Camundongo Pequeno</h1>
            <h2>Pacote com 15uni</h2>
            <span>R$ 105.00</span>
            <button>Comprar</button>
        </div>
    </div>
    <div class="card">
        <img src="imagens/rato.jpg" alt="#">

        <div>
            <h1>Rato Cinza</h1>
            <h2>Pacote com 10uni</h2>
            <span>R$ 50.00</span>
            <button>Comprar</button>
        </div>
    </div>
    <div class="card">
        <img src="imagens/sapo.webp" alt="#">

        <div>
            <h1>Sapo</h1>
            <h2>Pacote com 5uni</h2>
            <span>R$ 25.00</span>
            <button>Comprar</button>
        </div>
    </div>

    <div id="secao-de-destino3" class="temas">
        <p><strong>Outros alimentos</strong></p>
    </div>

    <p class="corpo-texto">
    <div class="card">
        <img src="imagens/monkey_cookies.webp" alt="#">

        <div>
            <h1>Ração para Macacos</h1>
            <h2>Pacote 3kg</h2>
            <span>R$ 51.00</span>
            <button>Comprar</button>
        </div>
    </div>
    <div class="card">
        <img src="imagens/feno.jpg" alt="#">
        <div>
            <h1>Feno</h1>
            <h2>Quantidade de 7kg</h2>
            <span>R$ 35.00</span>
            <button>Comprar</button>
        </div>
    </div>
    <div class="card">
        <img src="imagens/capim.jpeg" alt="#">
        <div>
            <h1>Capim</h1>
            <h2>Quantidade de 10kg</h2>
            <span>R$ 15.00</span>
            <button>Comprar</button>
        </div>
    </div>
</body>

</html>